typedef struct {
    const char* label;
    void (*action)(void);
} MenuItem;