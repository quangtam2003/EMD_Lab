void ADC_Initialize (void);
void ADC_StartConversion (void);
int ADC_ConversionDone (void);
int ADC_GetValue (void);